package model;

public class Species 
{
	protected int species_id;
	protected String name;
	protected String importance;
	protected String waysToProtect;
	protected boolean valid;
	
	public Species(String name, String importance, String waysToProtect) 
	{
		super();
		this.name = name;
		this.importance = importance;
		this.waysToProtect = waysToProtect;
	}
	public int getSpecies_id() {
		return species_id;
	}
	public void setSpecies_id(int species_id) {
		this.species_id = species_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getImportance() {
		return importance;
	}
	public void setImportance(String importance) {
		this.importance = importance;
	}
	public String getWaysToProtect() {
		return waysToProtect;
	}
	public void setWaysToProtect(String waysToProtect) {
		this.waysToProtect = waysToProtect;
	}
	public boolean isValid() {
		return valid;
	}
	public void setValid(boolean valid) {
		this.valid = valid;
	}
}
