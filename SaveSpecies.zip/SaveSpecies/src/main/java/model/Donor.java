package model;

import java.math.BigDecimal;

public class Donor 
{
	protected int donor_id;
	protected String donorName;
	protected String donorEmail;
	protected String donorAmount;
	protected String cardNumber;
	protected String cardMonth;
	protected String cardYear;
	protected String cardCVV;
	
	public Donor(String donorName, String donorEmail, String donorAmount, String cardNumber, String cardMonth, String cardYear, String cardCVV) 
	{
		this.donorName = donorName;
		this.donorEmail = donorEmail;
		this.donorAmount = donorAmount;
		this.cardNumber = cardNumber;
		this.cardMonth = cardMonth;
		this.cardYear = cardYear;
		this.cardCVV = cardCVV;
	}
	public int getDonor_id() {
		return donor_id;
	}
	public void setDonor_id(int donor_id) {
		this.donor_id = donor_id;
	}
	public String getDonorName() {
		return donorName;
	}
	public void setDonorName(String donorName) {
		this.donorName = donorName;
	}
	public String getDonorEmail() {
		return donorEmail;
	}
	public void setDonorEmail(String donorEmail) {
		this.donorEmail = donorEmail;
	}
	public String getDonorAmount() {
		return donorAmount;
	}
	public void setDonorAmount(String donorAmount) {
		this.donorAmount = donorAmount;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCardMonth() {
		return cardMonth;
	}
	public void setCardMonth(String cardMonth) {
		this.cardMonth = cardMonth;
	}
	public String getCardYear() {
		return cardYear;
	}
	public void setCardYear(String cardYear) {
		this.cardYear = cardYear;
	}
	public String getCardCVV() {
		return cardCVV;
	}
	public void setCardCVV(String cardCVV) {
		this.cardCVV = cardCVV;
	}
	
	
}
