package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Species;

public class SpeciesDao 
{
	String jdbcURL = "jdbc:mysql://localhost:3306/SaveSpecies";
	String dbUser = "root";
	String dbPassword = "Pr@shant4";
	
	private static final String INSERT_SPECIES_SQL = "Insert into species (name, importance, waysToProtect) VALUES (?, ?, ?);";
	private static final String SELECT_SPECIES_BY_ID = "select name, importance, waysToProtect from species where species_id = ?";
	private static final String SELECT_SPECIES_BY_NAME = "select name, importance, waysToProtect from species where name = ?";
	private static final String SELECT_ALL_SPECIES = "select * from species";
	private static final String DELETE_SPECIES_SQL = "delete from species where species_id = ?;";
	private static final String UPDATE_SPECIES_SQL = "update species set name = ?, importance = ?, waysToProtect = ? where species_id = ?;";
	
	public SpeciesDao() {
	}

	protected Connection getConnection() 
	{
		Connection connection = null;
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
		} 
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return connection;
	}
	
	public int insertSpecies(Species species) throws SQLException 
	{
		int count = 0;
		try 
		{
			Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SPECIES_SQL);
			preparedStatement.setString(1, species.getName());
			preparedStatement.setString(2, species.getImportance());
			preparedStatement.setString(3, species.getWaysToProtect());
			count = preparedStatement.executeUpdate();
		} 
		catch (SQLException e) {
			printSQLException(e);
		}
		
		return count;
	}

	public Species selectSpecies(int id) 
	{
		Species species = null;
		try
		{
			Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_SPECIES_BY_ID);
			preparedStatement.setInt(1, id);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) 
			{
				String name = rs.getString("name");
				String importance = rs.getString("importance");
				String waysToProtect = rs.getString("waysToProtect");
				species = new Species(name, importance, waysToProtect);
			}
		} 
		catch (SQLException e) {
			printSQLException(e);
		}
		return species;
	}
	
	public Species selectSpecies(String name) 
	{
		Species species = null;
		try
		{
			Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_SPECIES_BY_NAME);
			preparedStatement.setString(1, name);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) 
			{
				String na = rs.getString("name");
				String importance = rs.getString("importance");
				String waysToProtect = rs.getString("waysToProtect");
				species = new Species(na, importance, waysToProtect);
			}
		} 
		catch (SQLException e) {
			printSQLException(e);
		}
		return species;
	}

	public List<Species> selectAllSpecies() 
	{
		List<Species> species = new ArrayList<>();
		try 
		{
			Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_SPECIES);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) 
			{
				String name = rs.getString("name");
				String importance = rs.getString("importance");
				String waysToProtect = rs.getString("waysToProtect");
				species.add(new Species(name, importance, waysToProtect));
			}
		} 
		catch (SQLException e) {
			printSQLException(e);
		}
		return species;
	}

	public boolean deleteUser(int id) throws SQLException 
	{
		boolean rowDeleted = false;;
		try 
		{
			Connection connection = getConnection();
			PreparedStatement statement = connection.prepareStatement(DELETE_SPECIES_SQL);
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		catch (SQLException e) {
			printSQLException(e);
		}
		return rowDeleted;
	}

	public boolean updateUser(Species species) throws SQLException 
	{
		boolean rowUpdated = false;
		try 
		{	
			Connection connection = getConnection();
			PreparedStatement statement = connection.prepareStatement(UPDATE_SPECIES_SQL);
			statement.setString(1, species.getName());
			statement.setString(2, species.getImportance());
			statement.setString(3, species.getWaysToProtect());
			statement.setInt(4, species.getSpecies_id());
			rowUpdated = statement.executeUpdate() > 0;
		}
		catch (SQLException e) {
			printSQLException(e);
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}
}
