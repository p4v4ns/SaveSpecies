package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Donor;
import model.Species;

public class DonorDao 
{
	String jdbcURL = "jdbc:mysql://localhost:3306/SaveSpecies";
	String dbUser = "root";
	String dbPassword = "Pr@shant4";
	
	private static final String INSERT_DONOR_SQL = "insert into DONOR_INFORMATION (DONOR_NAME, DONOR_EMAIL, DONOR_AMOUNT, DONOR_CARD_NUMBER, DONOR_CARD_MONTH, DONOR_CARD_YEAR, DONOR_CARD_CVV) values (? ,?, ?, ?, ?, ?, ?)";
	
	public DonorDao() {
	}

	protected Connection getConnection() 
	{
		Connection connection = null;
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
		} 
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return connection;
	}
	
	public int insertDonor(Donor donor) throws SQLException 
	{
		int count = 0;
		try 
		{
			Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(INSERT_DONOR_SQL);
			preparedStatement.setString(1, donor.getDonorName());
			preparedStatement.setString(2, donor.getDonorEmail());
			preparedStatement.setString(3, donor.getDonorAmount());
			preparedStatement.setString(4, donor.getCardNumber());
			preparedStatement.setString(5, donor.getCardMonth());
			preparedStatement.setString(6, donor.getCardYear());
			preparedStatement.setString(7, donor.getCardCVV());
			count = preparedStatement.executeUpdate();
		} 
		catch (SQLException e) {
			printSQLException(e);
		}
		
		return count;
	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}
}
