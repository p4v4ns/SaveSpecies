package dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.User;

public class UserDAO 
{
	String jdbcURL = "jdbc:mysql://localhost:3306/SaveSpecies";
	String dbUser = "root";
	String dbPassword = "Pr@shant4";
	
	private static final String INSERT_USERS_SQL = "Insert into user (user_name, password, first_name, last_name, email_address) VALUES (?, ?, ?, ?, ?);";
	private static final String SELECT_USER_BY_ID = "select user_name, password, first_name, last_name, email_address from user where user_id = ?";
	private static final String SELECT_ALL_USERS = "select * from user";
	private static final String DELETE_USERS_SQL = "delete from user where user_id = ?;";
	private static final String UPDATE_USERS_SQL = "update user set user_name = ?, password = ?, first_name = ?, last_name = ?, email_address = ? where user_id = ?;";
	private static final String LOGIN_USER = "select * from user where user_name=? AND password=?";
	
	public UserDAO() {
	}

	protected Connection getConnection() 
	{
		Connection connection = null;
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
		} 
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return connection;
	}
	
	public User loginUser(String userName,String password) 
	{
	    User user = null;
	    try
	    {
	    	Connection connection = getConnection();
    		PreparedStatement preparedStatement = connection.prepareStatement(LOGIN_USER);
    		
	    	preparedStatement.setString(1,userName);
			preparedStatement.setString(2, password);
			ResultSet rs = preparedStatement.executeQuery();
     
			boolean more = rs.next();
			if (!more) 
			{
				user = new User();
				user.setValid(false);
			}
			else if(more) 
			{
				String firstName = rs.getString("first_name");
				String lastName = rs.getString("last_name");
				String email = rs.getString("email_address");
				String pass = rs.getString("password");
				user = new User();
				user.setFirstName(firstName);
				user.setLastName(lastName);
				user.setEmailAddress(email);
				user.setPassword(pass);
				
				user.setValid(true);
			}
		} catch (SQLException e) {
			//printSQLException(e);
		}
		return user;
	}

	
	public int insertUser(User user) throws SQLException 
	{
		int count = 0;
		try 
		{
			Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL);
			preparedStatement.setString(1, user.getUserName());
			preparedStatement.setString(2, user.getPassword());
			preparedStatement.setString(3, user.getFirstName());
			preparedStatement.setString(4, user.getLastName());
			preparedStatement.setString(5, user.getEmailAddress());
			count = preparedStatement.executeUpdate();
		} 
		catch (SQLException e) {
			printSQLException(e);
		}
		
		return count;
	}

	public User selectUser(int id) 
	{
		User user = null;
		try
		{
			Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_USER_BY_ID);
			preparedStatement.setInt(1, id);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) 
			{
				String user_name = rs.getString("user_name");
				String password = rs.getString("password");
				String first_name = rs.getString("first_name");
				String last_name = rs.getString("last_name");
				String email_address = rs.getString("email_address");
				user = new User(user_name, first_name, last_name, email_address, password);
			}
		} 
		catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}

	public List<User> selectAllUsers() 
	{
		List<User> users = new ArrayList<>();
		try 
		{
			Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_USERS);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) 
			{
				String user_name = rs.getString("user_name");
				String password = rs.getString("password");
				String first_name = rs.getString("first_name");
				String last_name = rs.getString("last_name");
				String email_address = rs.getString("email_address");
				users.add(new User(user_name, first_name, last_name, email_address, password));
			}
		} 
		catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteUser(int id) throws SQLException 
	{
		boolean rowDeleted = false;;
		try 
		{
			Connection connection = getConnection();
			PreparedStatement statement = connection.prepareStatement(DELETE_USERS_SQL);
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		catch (SQLException e) {
			printSQLException(e);
		}
		return rowDeleted;
	}

	public boolean updateUser(User user) throws SQLException 
	{
		boolean rowUpdated = false;
		try 
		{	
			Connection connection = getConnection();
			PreparedStatement statement = connection.prepareStatement(UPDATE_USERS_SQL);
			statement.setString(1, user.getUserName());
			statement.setString(2, user.getPassword());
			statement.setString(3, user.getFirstName());
			statement.setString(4, user.getLastName());
			statement.setString(5, user.getEmailAddress());
			statement.setInt(4, user.getId());
			rowUpdated = statement.executeUpdate() > 0;
		}
		catch (SQLException e) {
			printSQLException(e);
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}
	 

	
}
