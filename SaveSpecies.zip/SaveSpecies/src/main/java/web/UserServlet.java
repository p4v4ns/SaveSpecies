package web;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.DonorDao;
import dao.SpeciesDao;
import dao.UserDAO;
import model.Donor;
import model.Species;
import model.User;

@WebServlet("/")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDAO userDAO;
	private SpeciesDao speciesDAO;
	private DonorDao donorDAO;
	
	public void init() {
		userDAO = new UserDAO();
		speciesDAO = new SpeciesDao();
		donorDAO = new DonorDao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String action = request.getServletPath();
		String event = request.getParameter("_EXECEVENT");
		try 
		{
			if(event==null || event.isEmpty())
			{
				switch (action) {
				case "/new":
					showNewForm(request, response);
					break;
				case "/insert":
					insertUser(request, response);
					break;
				case "/delete":
					deleteUser(request, response);
					break;
				case "/edit":
					showEditForm(request, response);
					break;
				case "/update":
					updateUser(request, response);
					break;
				case "/login":
					loginUser(request, response);
					break;
				case "/logout":
					logoutUser(request, response);
					break;
				default:
					//listUser(request, response);
					break;
				}
			}
			
			else if(event.equals("ONLOGIN"))
			{
				  String userName = request.getParameter("user_name"); 
				  String password = request.getParameter("password"); 
				  User user = userDAO.loginUser(userName,password); 
				  request.setAttribute("user", user); 
				  if(user.isValid())
				  {
					  HttpSession session = request.getSession(true);
					  session.setAttribute("user",user); 
					  RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
					  dispatcher.forward(request, response); 
				  } 
				  else
					  response.sendRedirect("index.jsp");
			}
			else if(event.equals("ONSIGNUP"))
			{
				response.sendRedirect("signup.jsp");
			}
			else if(event.equals("ONSIGNUPCONFIRM"))
			{
				  String userName = request.getParameter("user_name"); 
				  String password = request.getParameter("password");
				  String firstName = request.getParameter("first_name");
				  String lastName = request.getParameter("last_name");
				  String emailAddress = request.getParameter("email_address");
				  User user = new User(userName, firstName, lastName, emailAddress, password);
				  if(userDAO.insertUser(user)>0)
					  user.setValid(true);
				  request.setAttribute("user", user); 
				  if(user.isValid())
				  {
					  HttpSession session = request.getSession(true);
					  session.setAttribute("user",user); 
					  RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
					  dispatcher.forward(request, response); 
				  } 
				  else
					  response.sendRedirect("index.jsp");
			}
			else if(event.equals("ONLOGOUT"))
			{
				response.sendRedirect("index.jsp");
			}
			else if(event.equals("ONHOME"))
			{
				response.sendRedirect("home.jsp");
			}
			else if(event.equals("ONEXISTING"))
			{
				List<Species> species = speciesDAO.selectAllSpecies();
				if(species.size()>0)
				{
					HttpSession session = request.getSession(true);
					session.setAttribute("existing",species.get(0));
				}
				RequestDispatcher dispatcher = request.getRequestDispatcher("existing.jsp");
				dispatcher.forward(request, response); 
			}
			else if(event.equals("ONADDNEW"))
			{
				response.sendRedirect("addNew.jsp");
			}
			else if(event.equals("ONDONATION"))
			{
				HttpSession session = request.getSession(true);
				session.removeAttribute("donor");
				response.sendRedirect("donate.jsp");
			}
			else if(event.equals("ONABOUTUS"))
			{
				response.sendRedirect("aboutUs.jsp");
			}
			else if(event.equals("ONSAVENEWSPECIES"))
			{
				  String name = request.getParameter("name"); 
				  String importance = request.getParameter("importance");
				  String waysToProtect = request.getParameter("waysToProtect");
				  Species species = new Species(name, importance, waysToProtect);
				  if(speciesDAO.insertSpecies(species)>0)
					  species.setValid(true);
				  request.setAttribute("species", species); 
				  if(species.isValid())
				  {
					  HttpSession session = request.getSession(true);
					  session.setAttribute("existing",species); 
					  RequestDispatcher dispatcher = request.getRequestDispatcher("existing.jsp");
					  dispatcher.forward(request, response); 
				  } 
				  else
					  response.sendRedirect("addNew.jsp");
			}
			else if(event.equals("ONDONATECONFIRM"))
			{
				  String doonorName = request.getParameter("donorName"); 
				  String donorEmail = request.getParameter("donorEmail");
				  String donorAmount = request.getParameter("donorAMount");
				  String cardNumber = request.getParameter("cardNumber");
				  String cardMonth = request.getParameter("cardMonth");
				  String cardYear = request.getParameter("cardYear");
				  String cardCVV = request.getParameter("cardCVV");
				  Donor donor = new Donor(doonorName, donorEmail, donorAmount, cardNumber, cardMonth, cardYear, cardCVV);
				  if(donorDAO.insertDonor(donor)>0)
				  {
					  HttpSession session = request.getSession(true);
					  session.setAttribute("donor",donor); 
					  RequestDispatcher dispatcher = request.getRequestDispatcher("donate.jsp");
					  dispatcher.forward(request, response); 
				  } 
				  else
					  response.sendRedirect("donate.jsp");
			}
			else if(event.equals("ONSEARCHSPECIES"))
			{
				  String name = request.getParameter("name");
				  Species species = speciesDAO.selectSpecies(name);
				  if(species!=null)
				  {
					  HttpSession session = request.getSession(true);
					  session.setAttribute("existing",species); 
					  RequestDispatcher dispatcher = request.getRequestDispatcher("existing.jsp");
					  dispatcher.forward(request, response); 
				  } 
				  else
				  {
					  	List<Species> speciesList = speciesDAO.selectAllSpecies();
						if(speciesList.size()>0)
						{
							HttpSession session = request.getSession(true);
							session.setAttribute("existing",speciesList.get(0));
						}
						RequestDispatcher dispatcher = request.getRequestDispatcher("existing.jsp");
						dispatcher.forward(request, response); 
				  }
			}
		} 
		catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}
	
	private void loginUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException 
	{
		response.sendRedirect("index.jsp");
	}
	
	private void logoutUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException 
	{
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request, response);
	}

	private void listUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException 
	{
		List<User> listUser = userDAO.selectAllUsers();
		request.setAttribute("listUser", listUser);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-form.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException 
	{
		int id = Integer.parseInt(request.getParameter("id"));
		User existingUser = userDAO.selectUser(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-form.jsp");
		request.setAttribute("user", existingUser);
		dispatcher.forward(request, response);
	}

	private void insertUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException 
	{
		String firstName = request.getParameter("first_name");
		String lastName = request.getParameter("last_name");
		String userName = request.getParameter("user_name");
		String password = request.getParameter("password");
		String email = request.getParameter("email_address");
		User newUser = new User(userName, firstName, lastName, email, password);
		userDAO.insertUser(newUser);
		response.sendRedirect("list");
	}

	private void updateUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException 
	{
		int id = Integer.parseInt(request.getParameter("id"));
		String firstName = request.getParameter("first_name");
		String lastName = request.getParameter("last_name");
		String userName = request.getParameter("user_name");
		String password = request.getParameter("password");
		String email = request.getParameter("email_address");
		User user = new User(userName, firstName, lastName, email, password);
		user.setId(id);
		userDAO.updateUser(user);
		response.sendRedirect("list");
	}

	private void deleteUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException 
	{
		int id = Integer.parseInt(request.getParameter("id"));
		userDAO.deleteUser(id);
		response.sendRedirect("list");
	}
}
